# KNX-Box-Gehäuse für Raspberry Pi mit kBerry

Robustes, verschraubtes Gehäuse für einen Raspberry Pi 3B, 3B+, 4B oder 5 mit aufgestecktem Weinzierl KNX BAOS 838 kBerry. Es ist für den Baustelleneinsatz ausgelegt: massive Wände, zurückgesetzte Anschlüsse, glatte Außenflächen. Die KNX-Klemme steht aus dem schlanken Deckel heraus und lässt sich bei geschlossenem Gehäuse abziehen.

Modelliert in [SolidCraft](https://github.com/tangency-labs/solidcraft), gedruckt im FDM-Verfahren. Es gibt nur diese eine Variante. Frühere Varianten (Pi 4B, Pi 5, Universal ohne kBerry, hoher kBerry-Deckel) liegen nur noch in der Git-Historie von `regetskcob/3d-design`.

**Stand: Vorschau.** Die Einsatzbohrungen sind per Stufenprobe am Druck bestimmt; das vollständige Gehäuse mit Pi und kBerry und der Boden für die Hutschiene (vor allem die Federkraft) sind noch nicht geprüft. Jedes Box-Release enthält diesen Ordner als `knx-box-case-<version>.zip`: die STLs und diese Beschreibung. Das SolidCraft-Modell und die Zeichnungen gehören nicht dazu. Quelle: `regetskcob/3d-design` (Stand 0422084).

## Dateien

| Datei | Inhalt |
|---|---|
| `KNX-Box-Case.solidcraft` | Modell mit allen Teilen, dazu Platzhalter für Pi und kBerry (nur zur Kontrolle, nicht exportieren) |
| `knx-box-case-base.stl` | Boden |
| `knx-box-case-base-din-rail.stl` | Boden mit Hutschienen-Aufnahme (TS35), Alternative zum normalen Boden |
| `knx-box-case-cover.stl` | Deckel |
| `knx-box-case-bridge.stl` | Modulbrücke, stützt das kBerry von unten |
| `knx-box-case-usb-cover.stl` | USB-Abdeckung, optional |
| `knx-box-case-fit-test.stl` | Passprobe für Deckel und Modul |
| `knx-box-case-insert-step-test.stl` | Stufenprobe für die Einschmelzgewinde (Modell `Einsatz-Stufenprobe.solidcraft`) |
| `knx-box-case-explosion-1-einsaetze` | Explosionszeichnung Schritt 1: Einschmelzen |
| `knx-box-case-explosion-2-montage` | Explosionszeichnung Schritt 2: Montage |
| `knx-box-case-hutschiene` | Geschlossenes Gehäuse auf einer TS35-Hutschiene mit angeschlossener Busleitung (`.png` transparent, `-white.png` weiß) |
| `knx-box-case-angeschlossen` | Geschlossenes Gehäuse mit angeschlossener KNX-Busleitung, Blick auf die Kabelseite (`.png` transparent, `-white.png` weiß) |

Alle STLs liegen in Drucklage und brauchen keine Stützen.

**Passt für** Pi 3B, 3B+, 4B und 5. Die 40-polige Stiftleiste und die Montagelöcher sitzen bei allen dreien an derselben Stelle, das kBerry liegt deshalb überall gleich. Pi 2B hat dieselbe Bauform wie Pi 3B, geprüft ist das nicht. **Nicht** passend: Pi Zero, Pi 1 A/B, Compute Modules, Pi 400/500.

## Maße

| | |
|---|---|
| Außenmaße (zusammengebaut) | 100 × 69 × 29,5 mm (L × B × H), die KNX-Klemme steht etwa 2,4 mm heraus |
| Boden | 100 × 69 × 7 mm (Rand 6 mm, Dome bis 7 mm) |
| Deckel | 100 × 69 × 23,5 mm, Decke innen bei 27,0 mm, 2,5 mm stark |
| Trennfuge Boden/Deckel | 6 mm über Unterkante |
| Ecken (senkrecht) | R 4,5 mm |
| Wandstärke | 6 mm (links, vorne, hinten), 8 mm (rechts, LAN/USB-Seite) |
| Innenraum | 86 × 57 mm, 0,5 mm Luft rund um die Platine |
| Pi-Platine | Unterseite 7 mm, Oberseite 8,5 mm über Gehäuseunterkante |
| kBerry-Platine | 19,9–21,5 mm über Gehäuseunterkante |

Ausrichtung: **vorne** = Strom/HDMI, **rechts** = LAN/USB, **links** = microSD, **hinten** = GPIO. Koordinaten: Ursprung ist die vordere linke Ecke der Pi-Platine, x nach rechts, y nach hinten, z ab Gehäuseunterkante. Für Gehäuse-Außenkoordinaten x und y je um 6,5 mm erhöhen.

## Öffnungen

| Öffnung | Lage | Bereich | Für |
|---|---|---|---|
| Fenster vorne | Vorderwand | x 4,5–59, z 5,9–15,5, außen 1,5 mm gefast | Micro-USB/USB-C, HDMI bzw. 2× Micro-HDMI, Audio. Die Oberkante fluchtet mit der Unterseite der Modulbrücke, die Fase gibt dicken Steckern Platz |
| Fenster rechts | rechte Wand | y 1,5–54,5, z 5,9–25 | LAN und 2× USB-Doppelbuchse, in beiden Anordnungen |
| Fenster links | linke Wand (Deckel) | y 18–38, z 5,9–12,5 | microSD, fluchtet mit der SD-Griffmulde im Boden. Power-Taster und PCIe-Anschluss des Pi 5 liegen dahinter verdeckt |
| SD-Griffmulde | linke Wand (Boden) | y 18–38, z 3,5–6 | microSD greifen |
| Klemmenöffnung mit Aderkanal | Deckel oben, nach links durch die Wand | x −0,5–18,5, y 12,6–26,6, ab z 21,9 | KNX-Klemme, Busleitung nach links |
| Stiftloch Ø 2,5 | Deckel oben | x 13,9, y 7,1 | Programmiertaste |
| Lüftung hinten | Rückwand | 15 Schlitze 2 mm breit, z 13,5–24,5 | |
| Lüftung vorne | Vorderwand über dem Fenster | 8 Schlitze 2 × 4 mm, z 20,5–24,5 | |

- Die Buchsen sitzen 4–6 mm hinter der Außenwand. Auch Stecker mit dickem Knickschutz gehen bis zum Anschlag hinein.
- Die microSD-Karte sitzt etwa 4 mm tief. Man greift sie mit dem Fingernagel oder einer Pinzette. Das ist gewollt, damit sie nicht versehentlich herausgezogen wird.
- Power-Taster und PCIe-Anschluss des Pi 5 sind bei geschlossenem Gehäuse nicht zugänglich.

## Deckel im Detail

Gemessene Lage des kBerry (Pi 4B, ±0,5 mm): Platine x 5,5–41, y 0–56. Bestückungsdruck der KNX-Klemme x 6,4–17,9, y 13,3–25,9. Höchste Punkte über der Gehäuseunterkante: Klemme 31,9 mm, großer Elko 27,9 mm.

| Element | Lage | Zweck |
|---|---|---|
| Klemmenöffnung | x −0,5–18,5, y 12,6–26,6, Spalt 0,6–0,7 mm zur Klemme | Klemme samt Leitung senkrecht abziehen, ohne den Deckel abzunehmen. Die Leitung läuft gerade nach links aus der Wand |
| Schürze | rund um Öffnung und Aderkanal, von der Decke bis 0,5 mm über die kBerry-Platine | hält Staub vom Innenraum fern und stützt das Modul von oben, wenn die Klemme abgezogen wird |
| Schürzenwände | vorn 1,2 mm, hinten 2,0 mm (bis y 28,6), rechts 1,7 mm (bis x 20,2); am SMD-Bauteil rechts vorn (ab x 19,7, y 9–13,6) auf 1,0 mm ausgespart | so dick, wie die Bauteile daneben es zulassen |
| Leisten an der Schürze | hinten und rechts außen, 1,5 × 1,7 mm | verbinden Schürze und Decke, gegen seitlichen Zug am Kabel. Links hängt die Schürze an der Gehäusewand |
| Fasen | Kanalboden außen und innen je 1,5 mm, Oberkanten der Öffnung 1 mm | keine scharfe Kante an der Leitung |
| Kanalboden | z 21,9 durchgehend von der Außenwand bis zur Klemme, ohne Steg, auf Höhe der Schürzenunterkante und unter der untersten Einführung der Klemme (ca. z 24,4) | auch mit zwei Leitungen (durchgeschleift) und allen vier Einführungen pro Pol bleibt nichts im Weg |
| Taschen in der Decke | über beiden Elkos (Ø 8 / Ø 7) und über der Programmiertaste (x 10,2–17,6, y 3,4–10,3), jeweils bis z 28,7 | 0,8 mm Luft über dem großen Elko, 0,8 mm Haut darüber |
| Führungen | links x 3,0–5,2 (y 1–9,8 und 30,5–56,5), rechts x 41,3–43,3 (y 1–56,5), Unterkante z 20 | seitlicher Halt, 0,3 mm Spiel zur Modulkante |
| Niederhalter (2×) | x 12,6–14,6 und 38,5–40,5, y −0,6–1,6, Unterkante z 22 | halten das vordere Modulende, 0,5 mm Luft |

Die Führungen und Niederhalter drücken auf kein Bauteil des Pi. Display- und Kamera-Stecker, GPIO-Stifte und SoC liegen tiefer oder daneben.

## Modulbrücke `knx-box-case-bridge.stl`

Das kBerry hat keine eigenen Befestigungslöcher und hängt nur an der Stiftleiste hinten. Die Brücke stützt das vordere Modulende von unten, damit beim Aufstecken der Klemme keine Kraft in die GPIO-Stifte geht.

| Element | Lage | Zweck |
|---|---|---|
| Pfosten | über den vorderen Pi-Löchern (3,5 / 3,5 Ø 6 und 61,5 / 3,5 Ø 5,5) | stehen auf der Pi-Platine über den Domen im Boden. Der rechte ist schmaler, wegen der PoE-Stifte des Pi 5 |
| Balken | x 3,5–61,5, y 0,5–6,5, z 15,5–19,7 | trägt die Vorderkante des Moduls, 0,2 mm Luft. Er liegt über USB-C, HDMI und Audio |
| Finger | x 7,5–12,5, y 6,5–14, Oberkante z 19,7 | stützt direkt vor der Klemme |
| Bohrungen | Ø 2,8 mit Senkung Ø 5 × 2 mm | Schraubenköpfe versenkt |

Kraftweg beim Aufstecken: Klemme → Modul → Brücke → Pfosten → Pi-Platine über den Domen. Beim Abziehen: Klemme → Modul → Schürze → Deckel. Der Gummipunkt unter dem Modul kann weg. Größe 64 × 13,5 × 11,2 mm.

## USB-Abdeckung `knx-box-case-usb-cover.stl`

Optionale Kappe für ungenutzte USB-Buchsen. Sie schließt das rechte Fenster bis auf die RJ45-Buchse.

- **Lage:** Die Platte füllt das Fenster vor den USB-Buchsen (x 88,2–93,5, y 1,7–36,5, z 6,1–24,8), bündig mit der Außenwand, 0,2 mm Luft.
- **Halt:** Vier gerundete Zapfen (11 × 1,8 mm) stecken etwa 6 mm tief in den Buchsen, in deren unterer Hälfte. Guter Halt ab etwa 4 mm.
- **Griffmulde:** an der Kante zur RJ45-Buchse, 2,4 mm tief. Zum Abziehen dort schräg herausziehen, die Kappe kippt um die vordere Kante.
- **Pi 4B:** Mulde zur RJ45-Buchse. **Pi 3B/3B+ und 5:** dieselbe Kappe um 180° gedreht einstecken (oben nach unten). Sie ist symmetrisch, die Mulde liegt dann wieder an der RJ45-Buchse.
- Am Pi noch nicht getestet. Offen ist, ob die Kontaktzunge in den Buchsen wirklich oben liegt.

## Boden für die Hutschiene `knx-box-case-base-din-rail.stl`

Alternative zum normalen Boden, wenn die Box im Verteiler auf einer Hutschiene TS35 (EN 60715, 35 × 7,5 mm) sitzen soll. Deckel, Einsätze, Modulbrücke und Montage bleiben gleich.

- **Ausrichtung:** Die kurze Seite (69 mm ≈ 4 TE) liegt längs der Schiene. Die KNX-Leitung zeigt nach oben, LAN und USB nach unten. Strom (USB-C) und HDMI liegen seitlich. Dort einen Winkelstecker verwenden oder etwas Abstand zum Nachbargerät lassen.
- **Höhe:** Der Boden ist 3 mm dicker als der normale, die Box ist damit 32,5 mm hoch. Mit Schiene ragt sie etwa 40 mm aus der Montageebene.
- **Schienennut:** 35,4 mm breit, quer über den ganzen Boden. Die Schienenschenkel liegen in 1,2 mm hohen Schlitzen hinter je einer Lippe, die 1,8 mm überdeckt.
- **Oben (KNX-Seite):** feste Lippe mit kleiner Einlauffase.
- **Unten (LAN-Seite):** Lippe an einem beidseitig gelagerten Federbalken (53 mm lang, 1,8 mm stark), mit 1 mm Einlauffase und 2,4 mm Federweg. Über dem Balken bleibt 1 mm Luft zum Boden, damit er beim Druck nicht anschmilzt.
- **Aufsetzen:** Box oben in die Schiene einhängen, unten andrücken, bis die Feder einrastet.
- **Abnehmen:** Einen Schraubendreher unten in das Loch der Entriegelungszunge stecken (Ø 2,5, nahe der LAN-Seite), nach außen ziehen. Die Feder gibt nach, die Box kippt oben aus der Schiene.
- **Deckelschrauben:** Die Senkungen gehen durch die zusätzliche Schicht. M3 × 8 passt weiter.
- **Druck:** Unterseite aufs Bett, ohne Stützen. Die Nut ist eine 35-mm-Brücke, die Federtasche eine 6-mm-Brücke.
- **Geprüft:** am Modell gegen ein TS35-Profil. Die Schiene ist in Endlage frei. Gegenprobe: Hebt sie sich 0,35 mm ab, liegt sie an beiden Lippen an. Am Druck noch nicht getestet, vor allem die Federkraft.

## Einschmelzgewinde

CNC Kitchen, M2.5 × 4 in die vier Dome des Bodens und M3 × 4 in die vier Ecksäulen des Deckels.

| Einsatz | Bohrung im Modell | Tiefe |
|---|---|---|
| M2.5 × 4 | Ø 3,4 | 5,5 mm, Dom Ø 7,5 mit Ø-6-Kragen |
| M3 × 4 | Ø 4,5 | 8 mm, Säule Ø 7,2 |

Die Maße stammen aus der Stufenprobe und gelten für **0,2 mm Schichthöhe**. Bei 0,28 mm fielen die Bohrungen gedruckt deutlich enger aus (Ø 3,0 → 2,5 mm, Ø 4,4 → 4,0 mm). Bei anderer Schichthöhe, anderem Material oder anderem Drucker die Passung vorher mit der Stufenprobe prüfen.

Stufenprobe `knx-box-case-insert-step-test.stl`: je fünf Dome und Säulen wie im Gehäuse. Die eingeprägten Punkte (1–5) zwischen den Reihen geben die Spalte an:

| Punkte | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| M2.5-Dom, Bohrung | 3,3 | **3,4** | 3,5 | 3,6 | 3,7 |
| M3-Säule, Bohrung | **4,5** | 4,6 | 4,7 | 4,8 | 4,9 |

Richtig ist die Spalte, in der der Einsatz mit dem glatten Ende gerade im Loch steht und nach dem Einschmelzen fest sitzt, ohne sich mitzudrehen.

## Montage

### Stückliste

| Anzahl | Teil | Zweck |
|---|---|---|
| 4 | Einschmelzgewinde M2.5 × 4 (CNC Kitchen) | in die Dome des Bodens |
| 4 | Einschmelzgewinde M3 × 4 (CNC Kitchen) | in die Ecksäulen des Deckels |
| 2 | Schraube M2.5 × 6 | Pi hinten in die Einsätze |
| 2 | Schraube M2.5 × 16 | durch Modulbrücke und Pi vorne in die Einsätze |
| 4 | Schraube M3 × 8, Zylinderkopf ISO 4762 (Kopf ≤ 5,5 mm) | Deckel von unten in die Einsätze |
| 1 | Modulbrücke (gedruckt) | stützt das kBerry |
| 1 | USB-Abdeckung (gedruckt, optional) | schließt ungenutzte USB-Buchsen |

### Schritt 1: Einschmelzen

Boden und Deckel liegen auf ihrer geschlossenen Seite, der Deckel also umgedreht. Die Einsätze mit dem Lötkolben von oben bündig setzen und abkühlen lassen. Siehe `knx-box-case-explosion-1-einsaetze`.

### Schritt 2: Montage

1. Den Gummipunkt unter dem vorderen Ende des kBerry entfernen.
2. Den Pi auf die Dome legen. Hinten links und rechts je eine M2.5 × 6 in die Einsätze.
3. Die Modulbrücke auf die beiden vorderen Pi-Löcher setzen und mit zwei M2.5 × 16 von oben durch Brücke und Pi in die Einsätze schrauben. Die Köpfe verschwinden in den Senkungen.
4. Das kBerry auf die GPIO-Pins 1–26 stecken. Es liegt vorne auf der Brücke auf.
5. Den Deckel aufsetzen. Die Schürze legt sich um die Klemme.
6. Die vier M3 × 8 von unten durch die Ecken des Bodens in die Einsätze des Deckels drehen. Die Köpfe sitzen versenkt (Senkung Ø 5,8 × 3,5 mm). Lochabstand 91,8 × 60,8 mm.
7. Die Busleitung durch den Aderkanal an die Klemme führen.
8. Optional die USB-Abdeckung einstecken.

Siehe `knx-box-case-explosion-2-montage`.

### Explosionszeichnungen

Je eine Datei `.png` mit transparentem Hintergrund, `-white.png` mit weißem Hintergrund und `-labels.json`. Gehäuse in Bambu-Grün, Platinen in realistischen Farben, Achsen gestrichelt. Die Bilder sind unbeschriftet. Die Hinweislinien enden an Punkten am Bildrand. Deren Pixelkoordinaten, die Ziele und Textvorschläge stehen in der `-labels.json`.

## Passprobe `knx-box-case-fit-test.stl`

Schnell druckbare Schablone: eine 1,2 mm dünne Deckelplatte über dem Modul mit Klemmenöffnung, Schürze, Stiftloch, Taschen, Führungen und Niederhaltern in Originallage, dazu ein Stück linke Wand mit Aderkanal.

1. Pi mit kBerry aufbauen, ohne Modulbrücke. Passprobe und Brücke belegen beide das vordere rechte Pi-Loch.
2. Die Passprobe aufsetzen. Ihre zwei Füße stehen über den beiden rechten Pi-Löchern.
3. Von unten je eine M2.5-Schraube (6–8 mm) durch die Pi-Löcher in die Kernlöcher der Füße drehen (Ø 2,2 mm, die Schraube schneidet ihr Gewinde selbst).
4. Prüfen:
   - Gleiten die Führungen ohne Klemmen an den Modulkanten vorbei?
   - Liegt die Klemme frei in der Öffnung, ohne an der Schürze zu klemmen?
   - Bleibt die Schürze über den Bauteilen neben der Klemme?
   - Trifft das Stiftloch die Taste?
   - Stoßen die Elkos an?

Die Platte der Passprobe ist dünner als die Decke, die Klemme steht dort deshalb weiter heraus (3,7 statt 2,4 mm).

## Kühlung

- Zwischen Pi-Oberseite und kBerry-Unterseite bleiben etwa 11 mm.
- Der offizielle Active Cooler des Pi 5 passt dort sehr wahrscheinlich nicht.
- Flache, aufklebbare passive Kühlkörper bis etwa 8 mm Höhe auf dem SoC passen. Ein 8 mm hoher Kühlkörper ist gegen das Gehäuse geprüft.

## Drucken

- **Material:** PETG oder ASA. PLA wird bei Wärme und Stößen schnell spröde und ist für den Baustelleneinsatz zu schwach.
- **Ausrichtung:** wie in den STLs. Der Boden liegt mit der Unterseite auf dem Bett, der Deckel mit der Oberseite, die USB-Abdeckung mit der Außenseite. Die Modulbrücke liegt mit der Balkenoberseite auf.
- **Wände:** 4–5 Perimeter, 20–40 % Füllung (Gyroid). Für die Sturzfestigkeit eher mehr Perimeter als mehr Füllung.
- **Schichthöhe:** 0,2 mm. Die Einsatzbohrungen sind auf diese Schichthöhe abgestimmt.
- **Außenflächen:** Deckeloberseite und Bodenunterseite bekommen die Oberfläche des Druckbetts.
- **Fäden im Aderkanal:** Retraction bzw. „Avoid crossing walls“ im Slicer verhindert Fäden über der Lücke.

## Geprüft

- **Am Modell, einzeln gegen Boden, Deckel und Passprobe:**
  - Pi 3B+, 4B und 5 mit allen Buchsen.
  - Das kBerry mit Platine, Klemme, Taste, Elkos, Optokopplern, Stiftleiste und den SMD-Bauteilen neben der Klemme.
  - Ein 8-mm-Kühlkörper.
  - Die Modulbrücke zusätzlich gegen USB-C, HDMI (auch das große des Pi 3), Audio, Kamera- und MIPI-Stecker sowie die PoE-Stifte des Pi 5.
- **Gegenproben:** Ein Modul, das 0,5 mm zur Seite rutscht oder sich um 0,7 mm hebt, stößt an Führung, Niederhalter bzw. Schürze. Eines, das 0,3 mm tiefer sitzt, liegt auf der Brücke auf.
- **Am Druck:**
  - Boden und Modulbrücke sind montiert.
  - Das Klemmenfenster wurde nach der ersten Passprobe angepasst.
  - Die Einsatzbohrungen sind mit der Stufenprobe bei 0,2 mm Schichthöhe bestimmt.

## Offene Punkte

- Schlanker Deckel mit Schürze und Stiftloch am echten Aufbau.
- USB-Abdeckung am Pi.
- Falltest aus 1 m.
- Die Status-LEDs des kBerry sind bei geschlossenem Deckel nicht zu sehen.
- Das Gehäuse ist nicht abgedichtet und hat keine IP-Schutzart.
