# KNX-Box-Gehäuse für Raspberry Pi

Robustes, verschraubtes Gehäuse für einen Raspberry Pi mit aufgestecktem HAT (z. B. KNX oder PoE), ausgelegt für den Baustelleneinsatz: massive Wände, zurückgesetzte Anschlüsse, geschlossener Deckel und Boden mit glatten Außenflächen.

Modelliert in [SolidCraft](https://github.com/tangency-labs/solidcraft), gedruckt im FDM-Verfahren.

**Stand: Vorschau.** Die Passform ist nur am Modell geprüft (siehe Offene Punkte); die kBerry-Variante, die Modulbrücke und die USB-Abdeckung sind noch nicht am echten Aufbau bestätigt. Jedes Box-Release enthält diesen Ordner als `knx-box-case-<version>.zip`: die STLs und diese Beschreibung. Die SolidCraft-Modelle aus der Tabelle gehören nicht dazu. Quelle: `regetskcob/3d-design` (Stand 071cd7d).

## Varianten und Dateien

| Variante | Passt für | Modell | STLs (Drucklage): Boden, Deckel |
|---|---|---|---|
| **Universal** (empfohlen) | Pi 3B, 3B+, 4B, 5 | `Pi-Universal-Case.solidcraft` | `knx-box-case-universal-base.stl`, `knx-box-case-universal-cover.stl` |
| Pi 5 | Pi 5 | `Pi5-Case.solidcraft` | `knx-box-case-pi5-base.stl`, `knx-box-case-pi5-cover.stl` |
| Pi 4B | Pi 4B | `Pi4-Case.solidcraft` | `knx-box-case-pi4-base.stl`, `knx-box-case-pi4-cover.stl` |
| kBerry | Pi 3B, 3B+, 4B, 5 mit Weinzierl KNX BAOS 838 kBerry | `Pi-kBerry-Case.solidcraft` | `knx-box-case-kberry-base.stl`, `knx-box-case-kberry-cover.stl`, Modulbrücke `knx-box-case-kberry-bridge.stl`, Passprobe `knx-box-case-kberry-fit-test.stl` |

- Der **Boden** ist bei allen drei Varianten geometrisch gleich. Unterschiede gibt es nur bei den Fenstern im Deckel.
- Die Einzelvarianten haben kleinere Fenster und schützen die Platine deshalb etwas besser. Das Universalgehäuse hat vorne ein größeres Fenster, damit die Anschlüsse aller Modelle durchpassen.
- Pi 2B hat dieselbe Bauform wie Pi 3B und sollte ins Universalgehäuse passen. Geprüft ist das nicht.
- **Nicht** passend: Pi Zero, Pi 1 A/B, Compute Modules, Pi 400/500 (andere Bauform).
- Zubehör für alle Varianten: USB-Abdeckung `knx-box-case-usb-cover.stl` (Modell in `Pi-kBerry-Case.solidcraft`, siehe unten).
- In den `.solidcraft`-Dateien liegen zusätzlich Platzhalter für Pi und HAT (`Pi5-Dummy`/`Pi4-Dummy`, `HAT-Dummy`). Sie dienen nur zur Kontrolle und dürfen nicht mit exportiert werden. Die STLs enthalten sie nicht.

## Maße

| | |
|---|---|
| Außenmaße (zusammengebaut) | 100 × 69 × 36,5 mm (L × B × H) |
| Boden | 100 × 69 × 7 mm (Rand 6 mm, Dome bis 7 mm) |
| Deckel | 100 × 69 × 30,5 mm |
| Trennfuge Boden/Deckel | 6 mm über Unterkante |
| Ecken (senkrecht) | R 4,5 mm |
| Wandstärke | 6 mm (links, vorne, hinten), 8 mm (rechts, LAN/USB-Seite) |
| Boden- und Deckelplatte | 3 mm, außen glatt |
| Innenraum | 86 × 57 mm, 0,5 mm Luft rund um die Platine |
| Platine | Unterseite 7 mm, Oberseite 8,5 mm über Gehäuseunterkante |
| Freie Höhe über der Platine | 25 mm (bis unter den Deckel) |
| Volumen (massiv) | Boden 26,2 cm³, Deckel 57,1 cm³ (Universal) |
| Gewicht | ca. 105 g PETG bei 100 % Füllung, real je nach Füllung weniger |

Ausrichtung im Folgenden: **vorne** = Seite mit Strom/HDMI, **rechts** = Seite mit LAN/USB, **links** = Seite mit microSD, **hinten** = GPIO-Seite.

## Platz für den HAT

- HAT auf Standard-Abstandshaltern von 11 mm: Die HAT-Unterseite liegt dann 19,5 mm über der Gehäuseunterkante.
- Über der HAT-Platine sind etwa **12 mm** frei für Bauteile wie Schraubklemmen oder einen Lüfter.
- Grundfläche: HAT-Standard 65 × 56,5 mm. Auch ein HAT in voller Pi-Größe (85 × 56 mm) hat Platz, solange er nicht über die Platine hinausragt.
- Kabeldurchführung für den HAT (z. B. KNX-Busleitung): links, 10 × 6 mm, auf HAT-Höhe (14–20 mm über der Pi-Oberseite). Sie liegt an einer allgemeinen Position. Wo die Klemme auf dem konkreten HAT sitzt, ist nicht berücksichtigt.
- Pi 5 Active Cooler unter dem HAT: nicht geprüft.

## Öffnungen

Positionen beziehen sich auf die Platine: Ursprung ist ihre vordere linke Ecke, x nach rechts, y nach hinten. z wird ab der Gehäuseunterkante gemessen.

| Öffnung | Lage | Größe / Bereich | Variante |
|---|---|---|---|
| Fenster vorne | Vorderwand | x 4,5–59, z 5,9–17,8 | Universal (Micro-USB, HDMI, USB-C, 2× Micro-HDMI, Audio) |
| | | x 4,5–59, z 5,9–16,5 | Pi 4B (USB-C, 2× Micro-HDMI, Audio) |
| | | x 4,5–45,5, z 5,9–14 | Pi 5 (USB-C, 2× Micro-HDMI) |
| Fenster rechts | rechte Wand | y 1,5–54,5, z 5,9–25 | alle (LAN + 2× USB-Doppelbuchse in beiden Anordnungen) |
| Fenster links | linke Wand (Deckel) | y 8–38, z 5,9–12,5 | Universal, Pi 5 (Power-Taster, microSD, PCIe-Flachband) |
| | | y 18–38, z 5,9–7,7 | Pi 4B (microSD) |
| SD-Griffmulde | linke Wand (Boden) | y 18–38, z 3,5–6 | alle |
| HAT-Kabel | linke Wand | y 42–52, z 22,5–28,5 | alle |
| Lüftung hinten | Rückwand | 15 Schlitze 2 × 18 mm, z 13,5–31,5 | alle |
| Lüftung vorne | Vorderwand über dem Fenster | 8 Schlitze 2 × 11 mm, z 20,5–31,5 | alle |

- Die Buchsen sitzen 4–6 mm hinter der Außenwand. Die Fenster sind so groß, dass auch Stecker mit dickem Knickschutz bis zum Anschlag reingehen.
- Die microSD-Karte sitzt etwa 4 mm tief. Man greift sie mit dem Fingernagel oder einer Pinzette. Das ist gewollt, damit sie nicht versehentlich herausgezogen wird.
- Der Power-Taster des Pi 5 ist nur mit einem Stift erreichbar.
- Deckel- und Bodenfläche haben keine Öffnungen. Die Lüftung beschränkt sich auf die Schlitze in der Vorder- und Rückwand.

## Außenflächen

- Deckeloberseite und Bodenunterseite sind durchgehend glatt, ohne Mulden.
- Die Oberseite hat keine Öffnungen (Ausnahme: die kBerry-Variante, siehe unten). Unten sind nur die vier versenkten M3-Schrauben in den Ecken.

## Montage

### Stückliste

| Anzahl | Teil | Zweck |
|---|---|---|
| 4 | Einschmelzgewinde M2.5 (CNC Kitchen, 4,6 × 4,0 mm) | in die Dome des Bodens (Bohrung Ø 4,0 × 5,5 mm, Dom Ø 7,5 mit Ø-6-Kragen oben) |
| 4 | Einschmelzgewinde M3 (CNC Kitchen Standard, 4,6 × 5,7 mm) | unten in die Ecksäulen des Deckels (Bohrung Ø 4,0 × 8 mm) |
| 4 | Abstandshalter M2.5 × 11 mm, Außen-/Innengewinde | durch die Pi-Löcher in die Einsätze, tragen den HAT |
| 4 | Schraube M2.5 × 5 | HAT auf den Abstandshaltern |
| 4 | Schraube M3 × 8, Zylinderkopf ISO 4762 (Kopf ≤ 5,5 mm) | Deckel von unten in die Einschmelzgewinde |

Ohne HAT kommen statt der Abstandshalter vier Schrauben M2.5 × 6 direkt in die Einsätze.

### Ablauf

1. Einschmelzgewinde mit dem Lötkolben setzen: vier M2.5 in die Dome des Bodens, vier M3 unten in die Ecksäulen des Deckels.
2. Den Pi auf die Dome legen und mit den Abstandshaltern verschrauben. Lochbild ist der Standard: 58 × 49 mm.
3. HAT aufstecken und festschrauben. Kabel durch die Durchführung links führen.
4. Deckel aufsetzen. Die Aussparungen sind nach unten offen und gleiten über die Buchsen.
5. Die vier M3 × 8 von unten durch die Ecken des Bodens in die Einschmelzgewinde des Deckels drehen. Die Köpfe sitzen versenkt (Senkung Ø 5,8 × 3,5 mm). Lochabstand 91,8 × 60,8 mm.

## Variante kBerry (Pi 3B/3B+, 4B, 5 + Weinzierl KNX BAOS 838 kBerry)

Abgeleitet vom Universalgehäuse. Boden, Wände, Fenster für Pi 3B/3B+, 4B und 5, Lüftung und Verschraubung sind gleich, die Außenmaße bleiben 100 × 69 × 36,5 mm. Der Boden ist identisch mit dem der anderen Varianten. Alle Änderungen betreffen den Deckel.

Die 40-polige GPIO-Leiste und die Montagelöcher sitzen bei allen drei Modellen an derselben Stelle. Das kBerry liegt deshalb überall gleich, und Führungen, Niederhalter und Klemmenöffnung passen für jedes Modell.

Koordinaten wie oben: Ursprung ist die vordere linke Ecke der Pi-Platine, z wird ab der Gehäuseunterkante gemessen. Zur Umrechnung in Gehäuse-Außenkoordinaten x und y je um 6,5 mm erhöhen.

### Lage des Moduls

Gemessen per Foto mit Lineal am echten Aufbau (Pi 4B), Genauigkeit etwa ±0,5 mm.

| | x | y | z |
|---|---|---|---|
| Modulplatine | 5,5–41,0 | 0–56 (so tief wie der Pi) | 19,9–21,5 |
| KNX-Klemme (rot vorne, grau hinten) | 7,3–18,0 | 13,3–26,8 | Oberkante 31,7 |
| Aderneinführung der Klemme | Seite nach **links** (microSD-Seite) | | 24,4–30,1 |
| Programmiertaste (Kappe) | 13,9 | 7,1 | Oberkante ca. 26 |
| Status-LEDs Host/KNX/Power | 36,3–39,9 | 32,7–35,3 | |

### Änderungen am Deckel

| Element | Lage | Zweck |
|---|---|---|
| KNX-Öffnung mit Kabelschlitz | Deckel oben x −0,5–22, y 10,3–30 (Gehäuse x 6–28,5, y 16,8–36,5). Geht als Schlitz durch die linke Wand, ab z 23,5 nach oben offen. | Stecker samt Busleitung senkrecht abziehen und aufstecken, ohne den Deckel abzunehmen. Die Leitung läuft gerade nach links aus der Wand, ohne Knick. Rund um den Stecker sind vorne, hinten und zur Gehäusemitte gut 3 mm Platz zum Greifen (nach der ersten Passprobe zur Mitte hin um 3 mm verbreitert). |
| Fasen | Schlitzunterkante innen und außen 1,5 mm, Oberkanten der Öffnung 1 mm | keine scharfe Kante an der Leitung |
| Stiftloch Ø 2,5 mm | über der Programmiertaste, x 13,9 / y 7,1 (Gehäuse 20,4 / 13,6) | Taste mit einem Stift drücken |
| Führungen links | x 3,0–5,2, y 1–9,8 und 30,5–56,5, Unterkante z 20 | seitlicher Halt, 0,3 mm Spiel zur Modulkante, greifen 1,5 mm über die Platinenkante |
| Führung rechts | x 41,3–43,3, y 1–56,5, Unterkante z 20 | wie links |
| Niederhalter (2×) | x 12,6–14,6 und 38,5–40,5, y −0,6–1,6, Unterkante z 22 | verhindern, dass das vordere Modulende hochkommt oder kippt. 0,5 mm Luft über der Platine, Auflage auf dem bauteilfreien Randstreifen |
| HAT-Kabeldurchführung links | entfällt | ersetzt durch den Kabelschlitz |

Die Führungen und Niederhalter hängen von der Deckelplatte herunter und drücken auf kein Bauteil des Pi: Display- und Kamera-Stecker, GPIO-Stifte und SoC liegen tiefer oder daneben.

### Modulbrücke `knx-box-case-kberry-bridge.stl`

Das kBerry hat keine eigenen Befestigungslöcher und hängt nur an der Stiftleiste hinten. Beim Aufstecken der KNX-Klemme drückt man bei y 13–27 nach unten. Ohne Stütze würde sich das vordere Modulende durchbiegen, und die Kraft ginge in die GPIO-Stifte. Die Brücke stützt das Modul von unten.

| Element | Lage | Zweck |
|---|---|---|
| Pfosten links | über dem Pi-Loch vorne links (3,5 / 3,5), Ø 6 | steht auf der Pi-Platine über dem Dom im Boden |
| Pfosten rechts | über dem Pi-Loch vorne rechts (61,5 / 3,5), Ø 5,5 | wie links. Der kleinere Durchmesser hält Abstand zu den PoE-Stiften des Pi 5 |
| Balken | x 3,5–61,5, y 0,5–6,5, z 15,5–19,7 | trägt die ganze Vorderkante des Moduls, 0,2 mm Luft. Er liegt über USB-C, HDMI und Audio, die alle höchstens 15 mm hoch sind |
| Finger | x 7,5–12,5, y 6,5–14, Oberkante z 19,7 | stützt direkt vor der Klemme, neben ihren Lötstiften |
| Bohrungen | Ø 2,8 mit Senkung Ø 5 × 2 mm | Schraubenköpfe versenkt, nichts drückt gegen das Modul |

- Kraftweg: Klemme → Modul → Brücke → Pfosten → Pi-Platine über den Domen im Boden.
- Das Modul liegt damit vorne auf der Brücke und hinten auf der Stiftleiste. Der Gummipunkt unter dem Modul kann weg.
- Größe 64 × 13,5 × 11,2 mm. Die STL liegt schon in Drucklage, Balkenoberseite aufs Bett, ohne Stützen.

### Außenflächen und LEDs

- Die Deckeloberseite ist bis auf die KNX-Öffnung und das Stiftloch glatt, ohne Sticker-Mulde.
- Die Status-LEDs sind bei geschlossenem Deckel nicht zu sehen. Ein Lichtfenster gibt es bisher nicht.

### Montage

- Den Gummipunkt unter dem vorderen Modulende entfernen. Unten stützt die Modulbrücke, oben halten die Niederhalter im Deckel.
- Den Pi auf die Dome legen. Hinten links und hinten rechts je eine M2.5 × 6 direkt in die Einsätze.
- Die Modulbrücke auf die beiden vorderen Pi-Löcher setzen und mit zwei M2.5 × 16 von oben durch Brücke und Pi in die Einschmelzgewinde schrauben. Die Köpfe verschwinden in den Senkungen.
- Dann das kBerry auf die GPIO-Pins 1–26 stecken. Es liegt vorne auf der Brücke auf.
- Höhe: Stecker und Leitung passen ohne Änderung, der Deckel bleibt 36,5 mm hoch.

### Explosionsdarstellung

`knx-box-case-kberry-explosion.png` (transparenter Hintergrund) und `knx-box-case-kberry-explosion-white.png` (weiß) zeigen die Montage: Gehäuse in Bambu-Grün, Platinen in realistischen Farben, Montageachsen gestrichelt in Grau. Die optionale USB-Abdeckung ist rechts neben dem Deckel dargestellt. Beschriftet sind sie bewusst nicht. Die Hinweislinien enden an Punkten am Bildrand. Zu jedem Punkt stehen die Pixelkoordinaten und ein Textvorschlag in `knx-box-case-kberry-explosion-labels.json`.

### Passprobe `knx-box-case-kberry-fit-test.stl`

Eine schnell druckbare Schablone, etwa ein Siebtel des Deckelvolumens: dünne Deckelplatte (1,2 mm) über dem Modul mit allen neuen Elementen in Originallage, dazu ein Stück linke Wand mit Kabelschlitz.

1. Pi mit kBerry aufbauen.
2. Die Schablone aufsetzen. Ihre zwei Füße stehen auf der Pi-Platine über den beiden **rechten** Pi-Löchern.
3. Von unten je eine M2.5-Schraube (6–8 mm) durch die Pi-Löcher in die Kernlöcher der Füße drehen (Ø 2,2 mm, die Schraube schneidet ihr Gewinde selbst). Die Schablone sitzt dann genau dort, wo später die Deckelplatte ist. Zusätzliche Abstandshalter braucht es dafür nicht.

Die Passprobe und die Modulbrücke belegen beide das vordere rechte Pi-Loch. Beide gleichzeitig zu montieren geht deshalb nicht. Am besten zuerst die Passprobe allein prüfen, danach die Brücke mit dem Modul.
4. Prüfen:
   - Gleiten die Führungen ohne Klemmen an den Modulkanten vorbei?
   - Berühren die Niederhalter keine Bauteile?
   - Liegt die Klemme mittig in der Öffnung, und lässt sie sich mit Leitung abziehen?
   - Trifft das Stiftloch die Taste?
   - Liegen die Aderneinführungen auf Höhe des Kabelschlitzes?

Erst danach den vollständigen Deckel drucken. Abweichungen bitte mit Richtung und Millimetern notieren.

### Kühlung

- Das kBerry steckt direkt auf der Stiftleiste. Zwischen Pi-Oberseite und Modulunterseite bleiben dadurch etwa 11 mm, bei jedem Gehäuse.
- Der offizielle Active Cooler des Pi 5 passt dort sehr wahrscheinlich nicht.
- Verwenden kann man flache, aufklebbare passive Kühlkörper mit höchstens etwa 8 mm Höhe auf dem SoC. Ein 8 mm hoher Kühlkörper ist gegen das Gehäuse geprüft.
- Für den Active Cooler müsste das Modul auf eine Stiftleisten-Verlängerung. Dann ändern sich Deckelhöhe und alle kBerry-Teile, das wäre eine eigene Variante.

### Geprüft

Einzelprüfung gegen Boden, Deckel und Passprobe: Pi 3B+, 4B und 5 mit allen Buchsen, kBerry-Platine, -Bauteilen, Klemme und Buchsenleiste, die Abstandshalter sowie ein 8-mm-Kühlkörper. Die Modulbrücke zusätzlich gegen USB-C, HDMI (auch das große des Pi 3), Audio, Kamera- und MIPI-Stecker sowie die PoE-Stifte des Pi 5.

Gegenprobe: Ein Modul, das 0,5 mm zur Seite rutscht oder sich um 0,7 mm hebt, stößt an Führung bzw. Niederhalter. Eines, das 0,3 mm tiefer sitzt, liegt auf der Brücke auf.

## USB-Abdeckung `knx-box-case-usb-cover.stl`

Kappe für ungenutzte USB-Buchsen. Sie schließt das rechte Fenster bis auf die RJ45-Buchse. Das Fenster ist bei allen Varianten gleich.

- **Lage:** Die Platte füllt das Fenster vor den USB-Buchsen, x 88,2–93,5, y 1,7–36,5, z 6,1–24,8. Sie schließt bündig mit der Außenwand ab und lässt rundum 0,2 mm Luft.
- **Halt:** Vier Zapfen, 11 × 1,8 mm, stecken etwa 6 mm tief in den Buchsen. Ein Test am USB-Stick zeigte guten Halt ab etwa 4 mm. Die Zapfen sitzen in der unteren Hälfte jeder Buchse, weil die Kontaktzunge beim Pi oben liegt.
- **Griffleiste:** An der Kante zur RJ45-Buchse ist eine Griffmulde eingelassen (2,4 mm tief, 3 mm breit, 14 mm hoch). Die Außenhaut davor ist 1,6 mm dick. Nichts steht über das Gehäuse hinaus.
- **Abziehen:** Die Kappe wird an der Mulde schräg herausgezogen und kippt dabei um die vordere Kante. Die Zapfenspitzen haben deshalb 2,5 mm Radius und 0,4 mm Fase, und seitlich bleiben je 0,75 mm Luft.
- **Pi 4B:** Kappe mit der Griffmulde hinten (zur RJ45-Buchse) einstecken.
- **Pi 3B/3B+ und 5:** Dort liegen USB und RJ45 vertauscht. Die Kappe einfach um 180° gedreht einstecken (oben nach unten). Platte, Zapfen und Griffmulde sind symmetrisch zur Plattenmitte (z 15,45). Die Mulde liegt dann wieder an der RJ45-Buchse, und die Zapfen sitzen weiter in der unteren Hälfte der Buchsen. Die Buchsenmitten passen auf 0,1 mm.
- **Druck:** Die Außenseite liegt flach auf dem Bett, die Zapfen stehen senkrecht. Es braucht keine Stützen. Das Dach der Griffmulde ist eine kurze Brücke.

## Drucken

- **Material:** PETG oder ASA. PLA wird bei Wärme und Stößen schnell spröde und ist für den Baustelleneinsatz zu schwach.
- **Ausrichtung:** Die STLs liegen schon richtig: der Boden mit der Unterseite aufs Bett, der Deckel mit der Oberseite aufs Bett. So zeigen alle Fenster nach oben und es braucht keine Stützen.
- **Wände:** 4–5 Perimeter, 20–40 % Füllung (Gyroid). Für maximale Sturzfestigkeit eher mehr Perimeter statt mehr Füllung.
- **Schichthöhe:** 0,2 mm.
- **Außenflächen:** Deckeloberseite und Bodenunterseite liegen glatt auf dem Druckbett und bekommen die Oberfläche des Betts (z. B. glatt oder strukturiert vom PEI-Blech).
- **Brücken:** Die Lüftungsschlitze (2 mm) und die Kabeldurchführung (10 mm) brauchen nur kurze Brücken.

## Konstruktionsdetails

- **Sturzschutz:** Ziel war, dass das Gehäuse einen Sturz aus 1 m ohne Schaden am Pi übersteht. Dafür sind die Wände massiv, die Ecken gerundet, und Boden und Deckel stehen über die Anschlüsse über und fangen Stöße ab, bevor eine Buchse getroffen wird.
- **Verschraubung:** Die Deckelschrauben sitzen in Säulen in den Gehäuseecken, außerhalb der glatten Deckelfläche.
- **Kollisionsprüfung:** Platine, alle Buchsen, microSD, Taster, PCIe-Anschluss, HAT und ein HAT-Lüfter wurden einzeln gegen Boden und Deckel geprüft, für Pi 3B+, 4B und 5. Die Maße stammen aus den offiziellen Maßzeichnungen von Raspberry Pi.

## Offene Punkte

- Die Passform ist bisher nur am Modell geprüft. Ein Probedruck mit echtem Pi und echten Steckern steht noch aus.
- Ein Falltest aus 1 m wurde noch nicht gemacht.
- Power-Taster und PCIe-Anschluss des Pi 5 sind in der offiziellen Zeichnung nur grob bemaßt. Die Öffnung ist deshalb großzügig.
- Das Gehäuse ist nicht abgedichtet und hat keine IP-Schutzart.
- Wärme: Mit einem PoE-HAT unter Dauerlast ist die Lüftung nur über die Seitenschlitze knapp. Die Temperatur sollte man im Betrieb beobachten (`vcgencmd measure_temp`).
